import { Router } from 'express';
import { eq, inArray } from 'drizzle-orm';
import { getDb } from '@mspi/shared-db';
import { tools, roleToolAccess } from '@mspi/shared-db/schema';
import { authenticateToken } from '@mspi/shared-auth';
const router = Router();
router.get('/my-tools', authenticateToken, async (req, res) => {
    try {
        const db = getDb();
        const { roleId } = req.user;
        if (!roleId) {
            res.json([]);
            return;
        }
        const accessRows = await db
            .select({ toolId: roleToolAccess.tool_id })
            .from(roleToolAccess)
            .where(eq(roleToolAccess.role_id, roleId));
        if (accessRows.length === 0) {
            res.json([]);
            return;
        }
        const toolIds = accessRows.map((r) => r.toolId);
        const userTools = await db
            .select()
            .from(tools)
            .where(inArray(tools.id, toolIds));
        res.json(userTools);
    }
    catch (error) {
        console.error('my-tools error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
export default router;
//# sourceMappingURL=tools.js.map